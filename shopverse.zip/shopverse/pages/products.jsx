/**
 * PRODUCTS PAGE - Client-Side Rendering (CSR)
 * Data di-fetch di sisi client menggunakan useEffect + useState
 * Fitur: search, filter by category, sort, pagination
 */

import { useState, useEffect, useCallback } from 'react';
import ProductCard from '../components/ProductCard';
import ProductSkeleton from '../components/ProductSkeleton';

export default function ProductsPage() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters (local state - useState)
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [sortBy, setSortBy] = useState('default');
  const [page, setPage] = useState(1);
  const PER_PAGE = 12;

  // Fetch categories
  useEffect(() => {
    fetch('https://dummyjson.com/products/categories')
      .then(r => r.json())
      .then(data => {
        const cats = Array.isArray(data) ? data.map(c => typeof c === 'object' ? c.name : c) : [];
        setCategories(cats.slice(0, 15));
      })
      .catch(() => {});
  }, []);

  // Fetch products - CSR: terjadi di browser, bukan server
  const fetchProducts = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      let url = 'https://dummyjson.com/products?limit=100&select=id,title,price,thumbnail,rating,category,discountPercentage,stock';
      if (selectedCategory) {
        url = `https://dummyjson.com/products/category/${selectedCategory}?limit=50`;
      }
      if (search.trim()) {
        url = `https://dummyjson.com/products/search?q=${encodeURIComponent(search)}&limit=50`;
      }
      const res = await fetch(url);
      if (!res.ok) throw new Error('Gagal mengambil data');
      const data = await res.json();
      setProducts(data.products || []);
      setPage(1);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [search, selectedCategory]);

  useEffect(() => {
    const timer = setTimeout(fetchProducts, search ? 400 : 0);
    return () => clearTimeout(timer);
  }, [fetchProducts, search]);

  // Sort
  const sorted = [...products].sort((a, b) => {
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    if (sortBy === 'rating') return b.rating - a.rating;
    return 0;
  });

  // Paginate
  const totalPages = Math.ceil(sorted.length / PER_PAGE);
  const paginated = sorted.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  return (
    <main style={{ minHeight: '100vh', background: '#F5F0E8' }}>
      {/* Header */}
      <div style={{ background: '#C4491B', padding: '32px 20px', color: 'white' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div className="flex items-center gap-3 mb-2">
            <span className="badge rounded-full" style={{ background: 'rgba(255,255,255,0.2)', color: 'white', border: '1px solid rgba(255,255,255,0.4)' }}>CSR</span>
            <span className="text-sm opacity-70">Client-Side Rendering</span>
          </div>
          <h1 style={{ fontSize: '2rem', marginBottom: '8px' }}>Products</h1>
          <p className="text-sm opacity-80">Data di-fetch langsung di browser menggunakan useEffect — rendering terjadi di sisi client</p>
        </div>
      </div>

      {/* Filters */}
      <div style={{ background: 'white', borderBottom: '1px solid rgba(26,26,26,0.1)', padding: '16px 20px', position: 'sticky', top: 0, zIndex: 10 }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', display: 'flex', gap: '12px', flexWrap: 'wrap', alignItems: 'center' }}>
          {/* Search */}
          <input
            value={search}
            onChange={e => { setSearch(e.target.value); setSelectedCategory(''); }}
            placeholder="🔍  Cari produk..."
            style={{
              flex: 1, minWidth: '200px', padding: '8px 14px', border: '2px solid #E5E0D5',
              borderRadius: '8px', outline: 'none', fontFamily: 'DM Sans, sans-serif', fontSize: '14px',
            }}
            onFocus={e => e.target.style.borderColor = '#C4491B'}
            onBlur={e => e.target.style.borderColor = '#E5E0D5'}
          />

          {/* Category */}
          <select
            value={selectedCategory}
            onChange={e => { setSelectedCategory(e.target.value); setSearch(''); }}
            style={{
              padding: '8px 14px', border: '2px solid #E5E0D5', borderRadius: '8px',
              fontFamily: 'DM Sans, sans-serif', fontSize: '14px', cursor: 'pointer', background: 'white',
            }}
          >
            <option value="">Semua Kategori</option>
            {categories.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>

          {/* Sort */}
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value)}
            style={{
              padding: '8px 14px', border: '2px solid #E5E0D5', borderRadius: '8px',
              fontFamily: 'DM Sans, sans-serif', fontSize: '14px', cursor: 'pointer', background: 'white',
            }}
          >
            <option value="default">Urutkan</option>
            <option value="price-asc">Harga ↑</option>
            <option value="price-desc">Harga ↓</option>
            <option value="rating">Rating ↓</option>
          </select>

          {products.length > 0 && (
            <span className="text-sm" style={{ color: '#888' }}>{products.length} produk</span>
          )}
        </div>
      </div>

      {/* Content */}
      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '32px 20px' }}>
        {error && (
          <div style={{ background: '#FEE2E2', border: '1px solid #FCA5A5', borderRadius: '8px', padding: '16px', marginBottom: '24px', color: '#991B1B' }}>
            ⚠️ {error}
            <button onClick={fetchProducts} className="btn-primary rounded ml-4 text-xs">Coba Lagi</button>
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '20px' }}>
          {loading
            ? Array.from({ length: 8 }).map((_, i) => <ProductSkeleton key={i} />)
            : paginated.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)
          }
        </div>

        {!loading && paginated.length === 0 && (
          <div className="text-center py-16" style={{ color: '#888' }}>
            <div className="text-4xl mb-4">🔍</div>
            <p>Produk tidak ditemukan</p>
          </div>
        )}

        {/* Pagination */}
        {!loading && totalPages > 1 && (
          <div className="flex justify-center gap-2 mt-10">
            <button onClick={() => setPage(p => Math.max(1, p-1))} disabled={page === 1} className="btn-outline rounded" style={{ opacity: page === 1 ? 0.4 : 1 }}>←</button>
            {Array.from({ length: Math.min(7, totalPages) }, (_, i) => {
              const p = page <= 4 ? i + 1 : page - 3 + i;
              if (p < 1 || p > totalPages) return null;
              return (
                <button
                  key={p}
                  onClick={() => setPage(p)}
                  className="rounded"
                  style={{
                    padding: '6px 14px', border: '2px solid', fontWeight: 500,
                    background: p === page ? '#C4491B' : 'transparent',
                    borderColor: p === page ? '#C4491B' : '#1A1A1A',
                    color: p === page ? 'white' : '#1A1A1A',
                  }}
                >
                  {p}
                </button>
              );
            })}
            <button onClick={() => setPage(p => Math.min(totalPages, p+1))} disabled={page === totalPages} className="btn-outline rounded" style={{ opacity: page === totalPages ? 0.4 : 1 }}>→</button>
          </div>
        )}
      </div>
    </main>
  );
}
