/**
 * CART PAGE
 * Demonstrasi Context API + useReducer untuk global state management
 */

import { useCart } from '../context/CartContext';
import Link from 'next/link';
import { useState } from 'react';

export default function CartPage() {
  const { items, removeItem, updateQty, clearCart, totalItems, totalPrice } = useCart();
  const [checkedOut, setCheckedOut] = useState(false);

  const handleCheckout = () => {
    clearCart();
    setCheckedOut(true);
  };

  if (checkedOut) {
    return (
      <main style={{ minHeight: '100vh', background: '#F5F0E8', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div className="text-center animate-fade-up" style={{ maxWidth: '400px', padding: '40px' }}>
          <div className="text-6xl mb-4">✅</div>
          <h2 style={{ fontSize: '1.8rem', marginBottom: '12px' }}>Pesanan Berhasil!</h2>
          <p style={{ color: '#666', marginBottom: '24px' }}>Terima kasih sudah berbelanja di ShopVerse.</p>
          <Link href="/products" className="btn-primary rounded-lg">Belanja Lagi</Link>
        </div>
      </main>
    );
  }

  return (
    <main style={{ minHeight: '100vh', background: '#F5F0E8' }}>
      {/* Header */}
      <div style={{ background: '#7C4A7C', padding: '32px 20px', color: 'white' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div className="flex items-center gap-3 mb-2">
            <span className="badge rounded-full" style={{ background: 'rgba(255,255,255,0.2)', color: 'white', border: '1px solid rgba(255,255,255,0.4)' }}>Context API</span>
            <span className="text-sm opacity-70">Global State Management</span>
          </div>
          <h1 style={{ fontSize: '2rem', marginBottom: '8px' }}>Shopping Cart</h1>
          <p className="text-sm opacity-80">State dikelola dengan Context API + useReducer — accessible di seluruh komponen</p>
        </div>
      </div>

      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '40px 20px' }}>
        {items.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-5xl mb-4">🛒</div>
            <h3 style={{ fontSize: '1.3rem', marginBottom: '8px' }}>Keranjang kosong</h3>
            <p style={{ color: '#888', marginBottom: '24px' }}>Tambahkan produk dari halaman Products atau Trending</p>
            <div className="flex gap-3 justify-center">
              <Link href="/products" className="btn-primary rounded-lg">Lihat Products (CSR)</Link>
              <Link href="/trending" className="btn-outline rounded-lg">Lihat Trending (SSR)</Link>
            </div>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: '32px', alignItems: 'start' }}>
            {/* Items */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 style={{ fontSize: '1.2rem' }}>{totalItems} Item</h2>
                <button onClick={clearCart} style={{ color: '#C4491B', fontSize: '13px', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'DM Sans, sans-serif' }}>
                  Hapus Semua
                </button>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {items.map((item, i) => (
                  <div
                    key={item.id}
                    className="animate-fade-up"
                    style={{
                      background: 'white', borderRadius: '12px', padding: '16px',
                      display: 'flex', gap: '16px', alignItems: 'center',
                      border: '1px solid rgba(26,26,26,0.08)',
                      animationDelay: `${i * 0.05}s`, animationFillMode: 'forwards', opacity: 0,
                    }}
                  >
                    <img src={item.thumbnail} alt={item.title} style={{ width: '72px', height: '72px', objectFit: 'contain', borderRadius: '8px', background: '#F8F5EF', padding: '4px' }} />
                    <div style={{ flex: 1 }}>
                      <p className="font-semibold text-sm">{item.title}</p>
                      <p className="text-sm" style={{ color: '#C4491B', fontFamily: 'Playfair Display, serif', fontWeight: 'bold' }}>${item.price}</p>
                    </div>

                    {/* Qty controls */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', border: '2px solid #E5E0D5', borderRadius: '8px', overflow: 'hidden' }}>
                      <button
                        onClick={() => updateQty(item.id, item.qty - 1)}
                        style={{ width: '32px', height: '32px', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 'bold', fontSize: '16px' }}
                      >−</button>
                      <span style={{ width: '28px', textAlign: 'center', fontWeight: '600' }}>{item.qty}</span>
                      <button
                        onClick={() => updateQty(item.id, item.qty + 1)}
                        style={{ width: '32px', height: '32px', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 'bold', fontSize: '16px', color: '#C4491B' }}
                      >+</button>
                    </div>

                    <div style={{ textAlign: 'right', minWidth: '70px' }}>
                      <p className="font-bold" style={{ fontFamily: 'Playfair Display, serif' }}>${(item.price * item.qty).toFixed(2)}</p>
                    </div>

                    <button onClick={() => removeItem(item.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#999', fontSize: '18px' }}>✕</button>
                  </div>
                ))}
              </div>
            </div>

            {/* Summary */}
            <div style={{ background: 'white', borderRadius: '12px', padding: '24px', border: '1px solid rgba(26,26,26,0.08)', position: 'sticky', top: '80px' }}>
              <h3 style={{ fontSize: '1.1rem', marginBottom: '16px' }}>Ringkasan Pesanan</h3>
              
              {items.map(item => (
                <div key={item.id} className="flex justify-between text-sm mb-2" style={{ color: '#666' }}>
                  <span className="truncate" style={{ maxWidth: '160px' }}>{item.title} ×{item.qty}</span>
                  <span>${(item.price * item.qty).toFixed(2)}</span>
                </div>
              ))}

              <hr style={{ margin: '16px 0', border: 'none', borderTop: '1px solid #E5E0D5' }} />
              
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm" style={{ color: '#666' }}>Subtotal</span>
                <span className="font-semibold">${totalPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm" style={{ color: '#666' }}>Ongkir</span>
                <span className="text-sm" style={{ color: '#4A7C59' }}>Gratis ✓</span>
              </div>
              
              <div className="flex justify-between items-center mb-6">
                <span className="font-bold">Total</span>
                <span className="font-bold text-xl" style={{ fontFamily: 'Playfair Display, serif', color: '#C4491B' }}>${totalPrice.toFixed(2)}</span>
              </div>

              <button onClick={handleCheckout} className="btn-primary rounded-lg w-full text-center">
                Checkout Sekarang
              </button>

              {/* State info */}
              <div style={{ background: '#F5F0E8', borderRadius: '8px', padding: '12px', marginTop: '16px' }}>
                <p className="text-xs font-semibold uppercase mb-1" style={{ color: '#7C4A7C', letterSpacing: '0.08em' }}>State via Context API</p>
                <code className="text-xs" style={{ color: '#555' }}>items: {items.length} | total: ${totalPrice.toFixed(2)}</code>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
