import Link from 'next/link';
import { useCart } from '../context/CartContext';

const features = [
  {
    icon: '⚡',
    label: 'SSR',
    title: 'Server-Side Rendering',
    desc: 'Trending page dirender di server setiap request untuk data selalu fresh.',
    href: '/trending',
    color: '#4A7C59',
  },
  {
    icon: '🖥️',
    label: 'CSR',
    title: 'Client-Side Rendering',
    desc: 'Products page fetch data di client dengan filter & search interaktif.',
    href: '/products',
    color: '#C4491B',
  },
  {
    icon: '📄',
    label: 'SSG',
    title: 'Static Site Generation',
    desc: 'Categories page di-generate saat build time untuk performa optimal.',
    href: '/categories',
    color: '#C9A84C',
  },
  {
    icon: '🛒',
    label: 'Context API',
    title: 'State Management',
    desc: 'Cart dikelola dengan Context API + useReducer — global state tanpa library eksternal.',
    href: '/cart',
    color: '#7C4A7C',
  },
];

export default function Home() {
  const { totalItems, totalPrice } = useCart();

  return (
    <main style={{ minHeight: '100vh', background: '#F5F0E8' }}>
      {/* Hero */}
      <section
        style={{
          background: 'linear-gradient(135deg, #1A1A1A 0%, #2C2C2C 100%)',
          padding: '80px 20px',
          textAlign: 'center',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        {/* Decorative circles */}
        <div style={{
          position: 'absolute', top: '-60px', right: '-60px', width: '300px', height: '300px',
          borderRadius: '50%', border: '60px solid rgba(196,73,27,0.15)',
        }} />
        <div style={{
          position: 'absolute', bottom: '-40px', left: '-40px', width: '200px', height: '200px',
          borderRadius: '50%', border: '40px solid rgba(201,168,76,0.1)',
        }} />

        <p className="badge rounded-full mb-4 inline-block" style={{ background: '#C4491B', color: 'white' }}>
          Next.js 14 · Platform Web · Tugas 1
        </p>
        <h1 style={{ color: '#F5F0E8', fontSize: 'clamp(2.5rem, 5vw, 4rem)', lineHeight: 1.1, marginBottom: '20px' }}>
          Shop<span style={{ color: '#C4491B' }}>Verse</span>
        </h1>
        <p style={{ color: '#B0A898', maxWidth: '500px', margin: '0 auto 32px', lineHeight: 1.7 }}>
          Demonstrasi implementasi <strong style={{ color: '#F5F0E8' }}>SSR</strong>, <strong style={{ color: '#F5F0E8' }}>CSR</strong>, <strong style={{ color: '#F5F0E8' }}>SSG</strong>, dan <strong style={{ color: '#F5F0E8' }}>State Management</strong> dalam satu aplikasi Next.js yang terintegrasi dengan DummyJSON API.
        </p>

        {totalItems > 0 && (
          <div className="animate-fade-up" style={{
            background: 'rgba(201,168,76,0.15)', border: '1px solid rgba(201,168,76,0.4)',
            borderRadius: '8px', padding: '12px 24px', display: 'inline-block', marginBottom: '24px',
          }}>
            <span style={{ color: '#C9A84C' }}>🛒 {totalItems} item di keranjang — Total: <strong>${totalPrice.toFixed(2)}</strong></span>
          </div>
        )}

        <div className="flex gap-3 justify-center flex-wrap">
          <Link href="/products" className="btn-primary rounded-lg">Lihat Produk (CSR)</Link>
          <Link href="/trending" className="btn-outline rounded-lg" style={{ color: '#F5F0E8', borderColor: '#F5F0E8' }}>Trending (SSR)</Link>
        </div>
      </section>

      {/* Feature cards */}
      <section style={{ maxWidth: '1100px', margin: '0 auto', padding: '60px 20px' }}>
        <h2 className="text-center mb-2" style={{ fontSize: '1.8rem' }}>Teknik Rendering yang Diimplementasikan</h2>
        <p className="text-center text-sm mb-10" style={{ color: '#888' }}>Klik kartu untuk melihat implementasinya</p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '24px' }}>
          {features.map((f, i) => (
            <Link key={f.label} href={f.href} style={{ textDecoration: 'none' }}>
              <div
                className="card-hover rounded-xl p-6 opacity-0 animate-fade-up"
                style={{
                  background: 'white',
                  border: `2px solid ${f.color}22`,
                  animationDelay: `${i * 0.1}s`,
                  animationFillMode: 'forwards',
                  cursor: 'pointer',
                }}
              >
                <div className="text-3xl mb-3">{f.icon}</div>
                <span className="badge rounded-full mb-2 inline-block" style={{ background: f.color, color: f.label === 'SSG' ? '#1A1A1A' : 'white' }}>
                  {f.label}
                </span>
                <h3 className="font-bold mb-2" style={{ fontSize: '1.05rem' }}>{f.title}</h3>
                <p className="text-sm" style={{ color: '#666', lineHeight: 1.6 }}>{f.desc}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Tech stack */}
      <section style={{ background: '#1A1A1A', padding: '40px 20px', textAlign: 'center' }}>
        <p className="text-sm mb-4" style={{ color: '#666', letterSpacing: '0.1em', textTransform: 'uppercase' }}>Tech Stack</p>
        <div className="flex gap-6 justify-center flex-wrap" style={{ color: '#F5F0E8' }}>
          {['Next.js 14', 'React 18', 'Context API', 'DummyJSON API', 'Tailwind CSS'].map(t => (
            <span key={t} className="badge rounded-full" style={{ border: '1px solid #444', color: '#B0A898' }}>{t}</span>
          ))}
        </div>
      </section>
    </main>
  );
}
