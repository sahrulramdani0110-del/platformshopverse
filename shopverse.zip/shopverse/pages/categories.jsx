/**
 * CATEGORIES PAGE - Static Site Generation (SSG)
 * getStaticProps dipanggil saat BUILD TIME, bukan saat request
 * Halaman di-generate sekali dan di-cache — sangat cepat
 */

import Link from 'next/link';

export async function getStaticProps() {
  const buildTime = new Date().toISOString();

  try {
    const res = await fetch('https://dummyjson.com/products/categories');
    const data = await res.json();

    // Fetch beberapa produk per kategori untuk gambar preview
    const categories = Array.isArray(data) ? data.slice(0, 12) : [];
    
    const enriched = await Promise.all(
      categories.map(async (cat) => {
        const slug = typeof cat === 'object' ? cat.slug : cat;
        const name = typeof cat === 'object' ? cat.name : cat;
        try {
          const pRes = await fetch(`https://dummyjson.com/products/category/${slug}?limit=3&select=id,thumbnail,price`);
          const pData = await pRes.json();
          return {
            slug,
            name,
            count: pData.total || 0,
            previews: (pData.products || []).map(p => p.thumbnail),
          };
        } catch {
          return { slug, name, count: 0, previews: [] };
        }
      })
    );

    return {
      props: {
        categories: enriched,
        buildTime,
      },
      // ISR: re-generate setiap 60 detik (opsional)
      // revalidate: 60,
    };
  } catch (e) {
    return {
      props: { categories: [], buildTime, error: 'Gagal mengambil data' },
    };
  }
}

const CATEGORY_COLORS = [
  '#C4491B', '#4A7C59', '#C9A84C', '#7C4A7C', '#4A6C8C',
  '#8C4A4A', '#4A8C7C', '#6C8C4A', '#8C6C4A', '#4A4A8C',
  '#8C4A6C', '#4A8C6C',
];

export default function CategoriesPage({ categories, buildTime, error }) {
  const time = new Date(buildTime).toLocaleString('id-ID');

  return (
    <main style={{ minHeight: '100vh', background: '#F5F0E8' }}>
      {/* Header */}
      <div style={{ background: '#C9A84C', padding: '32px 20px', color: '#1A1A1A' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div className="flex items-center gap-3 mb-2">
            <span className="badge rounded-full" style={{ background: 'rgba(26,26,26,0.2)', color: '#1A1A1A', border: '1px solid rgba(26,26,26,0.3)' }}>SSG</span>
            <span className="text-sm opacity-70">Static Site Generation</span>
          </div>
          <h1 style={{ fontSize: '2rem', marginBottom: '8px' }}>Product Categories</h1>
          <p className="text-sm opacity-80">Halaman ini di-generate pada BUILD TIME — bukan saat request</p>
        </div>
      </div>

      {/* SSG Info */}
      <div style={{ background: '#FFF8E6', borderBottom: '2px solid #C9A84C', padding: '12px 20px' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', display: 'flex', gap: '24px', flexWrap: 'wrap', alignItems: 'center' }}>
          <div>
            <span className="text-xs font-semibold uppercase" style={{ color: '#8C6C20', letterSpacing: '0.08em' }}>Di-generate pada build time:</span>
            <p className="text-sm font-bold" style={{ color: '#1A1A1A' }}>{time}</p>
          </div>
          <div>
            <span className="text-xs font-semibold uppercase" style={{ color: '#8C6C20', letterSpacing: '0.08em' }}>Cara Kerja SSG</span>
            <p className="text-sm" style={{ color: '#555' }}>getStaticProps berjalan saat `next build` → HTML statis disimpan → served langsung tanpa server computation</p>
          </div>
          <span className="badge rounded-full" style={{ background: '#C9A84C', color: '#1A1A1A', marginLeft: 'auto' }}>
            ⚡ Super cepat!
          </span>
        </div>
      </div>

      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '40px 20px' }}>
        {error && (
          <div style={{ background: '#FEE2E2', border: '1px solid #FCA5A5', borderRadius: '8px', padding: '16px', marginBottom: '24px', color: '#991B1B' }}>
            ⚠️ {error}
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '20px' }}>
          {categories.map((cat, i) => (
            <Link key={cat.slug} href={`/products?category=${cat.slug}`} style={{ textDecoration: 'none' }}>
              <div
                className="card-hover rounded-xl overflow-hidden opacity-0 animate-fade-up"
                style={{
                  background: 'white',
                  border: `2px solid ${CATEGORY_COLORS[i % CATEGORY_COLORS.length]}22`,
                  animationDelay: `${i * 0.06}s`,
                  animationFillMode: 'forwards',
                }}
              >
                {/* Preview images */}
                <div style={{ display: 'flex', gap: '2px', height: '120px', overflow: 'hidden', background: '#F8F5EF', borderBottom: `3px solid ${CATEGORY_COLORS[i % CATEGORY_COLORS.length]}` }}>
                  {cat.previews.length > 0 ? cat.previews.map((src, j) => (
                    <img key={j} src={src} alt="" style={{ flex: 1, objectFit: 'contain', padding: '8px', background: '#F8F5EF' }} loading="lazy" />
                  )) : (
                    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '3rem' }}>🛍️</div>
                  )}
                </div>

                <div className="p-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold capitalize" style={{ fontSize: '1rem' }}>
                      {cat.name?.replace(/-/g, ' ')}
                    </h3>
                    <span className="badge rounded-full" style={{ background: CATEGORY_COLORS[i % CATEGORY_COLORS.length], color: 'white' }}>
                      {cat.count}
                    </span>
                  </div>
                  <p className="text-xs mt-1" style={{ color: '#888' }}>
                    {cat.count} produk tersedia →
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </main>
  );
}
