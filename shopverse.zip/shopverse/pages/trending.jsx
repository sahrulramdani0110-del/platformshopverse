/**
 * TRENDING PAGE - Server-Side Rendering (SSR)
 * getServerSideProps dipanggil di server setiap request
 * Data selalu fresh, di-render di server sebelum dikirim ke client
 */

import ProductCard from '../components/ProductCard';

export async function getServerSideProps(context) {
  const timestamp = new Date().toISOString();

  try {
    // Fetch top-rated products - SSR: berjalan di server, bukan di browser
    const [topRatedRes, newArrivalsRes] = await Promise.all([
      fetch('https://dummyjson.com/products?limit=8&sortBy=rating&order=desc'),
      fetch('https://dummyjson.com/products?limit=4&skip=20'),
    ]);

    const topRated = await topRatedRes.json();
    const newArrivals = await newArrivalsRes.json();

    return {
      props: {
        topRatedProducts: topRated.products || [],
        newArrivals: newArrivals.products || [],
        renderedAt: timestamp,
        requestInfo: {
          userAgent: context.req.headers['user-agent']?.split(' ').slice(-1)[0] || 'Unknown',
          timestamp,
        },
      },
    };
  } catch (e) {
    return {
      props: {
        topRatedProducts: [],
        newArrivals: [],
        renderedAt: timestamp,
        requestInfo: { userAgent: 'Unknown', timestamp },
        error: 'Gagal mengambil data dari server',
      },
    };
  }
}

export default function TrendingPage({ topRatedProducts, newArrivals, renderedAt, requestInfo, error }) {
  const time = new Date(renderedAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  return (
    <main style={{ minHeight: '100vh', background: '#F5F0E8' }}>
      {/* Header */}
      <div style={{ background: '#4A7C59', padding: '32px 20px', color: 'white' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div className="flex items-center gap-3 mb-2">
            <span className="badge rounded-full" style={{ background: 'rgba(255,255,255,0.2)', color: 'white', border: '1px solid rgba(255,255,255,0.4)' }}>SSR</span>
            <span className="text-sm opacity-70">Server-Side Rendering</span>
          </div>
          <h1 style={{ fontSize: '2rem', marginBottom: '8px' }}>Trending Now</h1>
          <p className="text-sm opacity-80">Halaman ini di-render di server setiap kali ada request baru</p>
        </div>
      </div>

      {/* SSR Info panel */}
      <div style={{ background: '#EDF7F0', borderBottom: '2px solid #4A7C59', padding: '12px 20px' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', display: 'flex', gap: '24px', flexWrap: 'wrap', alignItems: 'center' }}>
          <div>
            <span className="text-xs font-semibold uppercase" style={{ color: '#4A7C59', letterSpacing: '0.08em' }}>Dirender di server pada:</span>
            <p className="text-sm font-bold" style={{ color: '#1A1A1A' }}>{time}</p>
          </div>
          <div>
            <span className="text-xs font-semibold uppercase" style={{ color: '#4A7C59', letterSpacing: '0.08em' }}>Cara Kerja SSR</span>
            <p className="text-sm" style={{ color: '#555' }}>getServerSideProps → server fetch data → HTML dikirim ke browser (refresh untuk melihat waktu berubah)</p>
          </div>
          <span className="badge rounded-full" style={{ background: '#4A7C59', color: 'white', marginLeft: 'auto' }}>
            ↺ Refresh = data baru
          </span>
        </div>
      </div>

      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '40px 20px' }}>
        {error && (
          <div style={{ background: '#FEE2E2', border: '1px solid #FCA5A5', borderRadius: '8px', padding: '16px', marginBottom: '24px', color: '#991B1B' }}>
            ⚠️ {error}
          </div>
        )}

        {/* Top Rated */}
        <section className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <h2 style={{ fontSize: '1.5rem' }}>⭐ Top Rated Products</h2>
            <span className="badge rounded-full" style={{ background: '#C9A84C', color: '#1A1A1A' }}>Sorted by rating</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '20px' }}>
            {topRatedProducts.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </section>

        {/* New Arrivals */}
        <section>
          <div className="flex items-center gap-3 mb-6">
            <h2 style={{ fontSize: '1.5rem' }}>🆕 New Arrivals</h2>
            <span className="badge rounded-full" style={{ background: '#C4491B', color: 'white' }}>Fresh stock</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '20px' }}>
            {newArrivals.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
