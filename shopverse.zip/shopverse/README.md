# ShopVerse — Next.js Web Platform App

> Tugas 1 Individu — Pengembangan Aplikasi Berbasis Platform  
> Topik: Implementasi Teknik Pengembangan pada Platform Web

## 🚀 Tech Stack
- **Framework**: Next.js 14 (Pages Router)
- **UI**: React 18 + Tailwind CSS
- **API**: DummyJSON (https://dummyjson.com)
- **State**: Context API + useReducer (global cart)

---

## 📂 Struktur Project

```
shopverse/
├── pages/
│   ├── _app.jsx          # App wrapper + CartProvider
│   ├── index.jsx         # Homepage (landing)
│   ├── products.jsx      # CSR — Client-Side Rendering
│   ├── trending.jsx      # SSR — Server-Side Rendering
│   ├── categories.jsx    # SSG — Static Site Generation
│   └── cart.jsx          # Cart (Context API state)
├── components/
│   ├── Navbar.jsx        # Navigation bar
│   ├── ProductCard.jsx   # Reusable product card
│   └── ProductSkeleton.jsx # Loading skeleton
├── context/
│   └── CartContext.jsx   # Context API + useReducer
├── styles/
│   └── globals.css       # Global styles
├── next.config.js
├── tailwind.config.js
└── package.json
```

---

## 🎯 Teknik Rendering

### 1. SSR — Server-Side Rendering (`/trending`)
```js
// pages/trending.jsx
export async function getServerSideProps(context) {
  const data = await fetch('https://dummyjson.com/products?limit=8&sortBy=rating&order=desc');
  return { props: { products: data.products, renderedAt: new Date().toISOString() } };
}
```
- Dijalankan **di server setiap request**
- Data selalu fresh (lihat timestamp di halaman)
- Cocok untuk konten yang sering berubah

### 2. CSR — Client-Side Rendering (`/products`)
```js
// pages/products.jsx
useEffect(() => {
  fetch('https://dummyjson.com/products').then(...).then(setProducts);
}, [selectedCategory, search]);
```
- Dijalankan **di browser (client)**
- Fitur: search real-time, filter kategori, sort, pagination
- Skeleton loading saat data belum siap

### 3. SSG — Static Site Generation (`/categories`)
```js
// pages/categories.jsx
export async function getStaticProps() {
  const data = await fetch('https://dummyjson.com/products/categories');
  return { props: { categories: data, buildTime: new Date().toISOString() } };
}
```
- Dijalankan **saat `next build`**, bukan saat request
- HTML statis disimpan dan di-cache — sangat cepat
- Timestamp "build time" tidak berubah walau di-refresh

### 4. State Management — Context API + useReducer (`/cart`)
```js
// context/CartContext.jsx
const cartReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_ITEM': ...
    case 'REMOVE_ITEM': ...
    case 'UPDATE_QTY': ...
    case 'CLEAR_CART': ...
  }
};
const [state, dispatch] = useReducer(cartReducer, { items: [] });
```
- Context API untuk global state tanpa library eksternal
- useReducer untuk logic yang lebih kompleks dari useState
- Cart accessible dari semua halaman

---

## ✨ Fitur Tambahan

- **Skeleton Loading** — saat CSR fetch data
- **Search + Filter** — real-time di halaman products
- **Pagination** — 12 produk per halaman
- **Error Handling** — tampilan error + tombol retry
- **Responsive Design** — grid yang menyesuaikan layar
- **Lazy Loading** — gambar dengan `loading="lazy"`
- **Animasi** — fade-up staggered untuk UX yang smooth

---

## ⚙️ Cara Menjalankan

```bash
# Install dependencies
npm install

# Development
npm run dev
# → http://localhost:3000

# Build (untuk melihat SSG berjalan)
npm run build
npm run start
```

---

## 📊 Perbandingan Teknik Rendering

| Teknik | Kapan Render | Data | Kecepatan | Use Case |
|--------|-------------|------|-----------|----------|
| SSR | Setiap request (server) | Selalu fresh | Sedang | Data dinamis, SEO penting |
| CSR | Di browser | Fetch saat load | Lambat awal | Interaktivitas tinggi |
| SSG | Saat build | Statis | Tercepat | Konten jarang berubah |

---

## 🔗 API yang Digunakan

- `GET /products` — daftar produk
- `GET /products/categories` — daftar kategori  
- `GET /products/category/:slug` — produk per kategori
- `GET /products/search?q=` — pencarian produk
